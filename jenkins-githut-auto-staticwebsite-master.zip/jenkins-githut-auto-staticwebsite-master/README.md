# staticwebsite-new
this is a static website application launching from jenkins
testing cicd jenkins using organization
###########
This is my pull request testing

hi this is modification 
new line pr creating
second pr request to check auto




